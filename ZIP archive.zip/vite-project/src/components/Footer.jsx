import "../blocks/Footer.css";

function Footer() {
  return (
    <div className="footer">
      <p className="footer__credit">Developed by Name Surname</p>
      <p className="footer__credit">2025</p>
    </div>
  );
}
export default Footer;
